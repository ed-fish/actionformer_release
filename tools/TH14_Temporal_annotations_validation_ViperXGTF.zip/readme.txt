THUMOS CHALLENGE 2014
http://crcv.ucf.edu/THUMOS14/

------------------------------------------------------------


The temporal annotations of the videos were generated using VIPER tool.
VIPER: http://viper-toolkit.sourceforge.net/

The xgtf annotations files readable by VIPER are provided in this zipped folder. 

IMPORTANT: the temporal annotations were performed on the full-sized un-subsampled 
version of the validation videos (mpeg format). The videos shared on the 
competition webpage were slightly resized and are in mp4 format which could cause 
frame-rate changes. It is important to use the original mpeg validation videos 
when using the xgtf files to preserve the correct relationship between frames 
numbers in the videos and xgtf files.

Original mpeg validation videos:
http://storage.googleapis.com/crcv/TH14_validation_set_mpeg.zip

Resized mp4 validation videos:
http://storage.googleapis.com/crcv/TH14_validation_set_mp4.zip

Temporal annotations in seconds:
http://crcv.ucf.edu/THUMOS14/Validation_set/TH14_Temporal_annotations_validation.zip